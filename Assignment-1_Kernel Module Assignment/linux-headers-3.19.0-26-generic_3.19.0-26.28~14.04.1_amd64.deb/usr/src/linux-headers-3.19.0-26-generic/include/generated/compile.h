/* This file is auto generated, version 28~14.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#28~14.04.1 SMP Wed Sep 2 22:39:12 PDT 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
